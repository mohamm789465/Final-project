import 'package:easy_splash_screen/easy_splash_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:parking_app/page/home.dart';
import 'package:parking_app/page/mobile_sign_in_page.dart';

import 'bottom_nav_controller.dart';

class SplashPage extends StatefulWidget {
  SplashPage({Key? key}) : super(key: key);

  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isLoggedIn();
  }
  Future<void> isLoggedIn() async {
    final auth = FirebaseAuth.instance;
    final user = auth.currentUser;
    if (user != null) {
      Future.delayed(Duration.zero, () {
         Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => BottomNavController()));
      });

    }
  }

  @override
  Widget build(BuildContext context) {
    return EasySplashScreen(
      logo: Image.asset(
          'assets/images/s_logo.png',),
      logoWidth: 150,
      title: Text(
        "Best Park",
        style: TextStyle(
          fontSize: 20,
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      gradientBackground:  LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.centerRight,
        colors: [
         Colors.blue,
          Colors.green,
        ],
      ),
      loaderColor: Colors.white,
      showLoader: true,
      loadingText: Text("Loading.....",style: TextStyle(
        color: Colors.white,
        fontSize: 12,
        fontWeight: FontWeight.bold,
      ),),
      navigator: MobileSignInView(),
      durationInSeconds: 5,
    );
  }
}