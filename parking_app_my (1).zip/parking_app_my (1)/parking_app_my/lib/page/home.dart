import 'dart:async';
import 'dart:async';
import 'dart:async';
import 'dart:async';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:parking_app/page/parking_data.dart';

import 'add_parking_page.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  initState() {
    _determinePosition();
    // TODO: implement initState
    super.initState();
    readData();
  }

  Completer<GoogleMapController> _controller = Completer();
  Marker? currentPostion;

  readData() async {
    final ref = FirebaseDatabase.instance.ref();
    final snapshot = await ref.child('UserParking');

    snapshot.onValue.listen((event) {
      List<Map<String, dynamic>> data = [];
      // _markers.add(currentPostion!);
      for (final child in event.snapshot.children) {
        // Handle the post.
        print("child is now: ${child.value}");
        // Convert to map.
        var mapValue = child.value as Map<dynamic, dynamic>;
        // Get the name value.
        var uid = mapValue['uid'];
        var name = mapValue['parking_name'];
        var address = mapValue['address'];
        var park_username = mapValue['park_user_name'];
        var park_useremaile = mapValue['park_user_email'];
        double lat = mapValue['lat'];
        double long = mapValue['long'];
        // Print the name.

        // print lat long
        print("kkore lat $lat and long $long");

        print("parkids  ${child.key}");
        String? parkId = child.key;

        Marker marker = Marker(
          markerId: MarkerId(parkId!),
          position: LatLng(lat, long),
          infoWindow: InfoWindow(title: name),
          onTap: () {
            print("mytest  ${uid}");
            // setState(() {
            //
            // });
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (
                  context,
                ) =>
                        ParkingDetails(parkId, uid, name, address,
                            park_username, park_useremaile)));
          },
        );
        list.add(marker);
      }

      setState(() {
        _markers.addAll(list);
      });
    }, onError: (error) {
      // Error.
    });
  }

  bool isLoading = false;

  final List<Marker> list = [];

  GoogleMapController? mapController;

  CameraPosition? _kGooglePlex;

  Set<Marker> _markers = {
    /* Marker(
        markerId: MarkerId("2"),
        position: LatLng(22.3667, 91.8000),
        infoWindow: InfoWindow(title: "Chatgram")),*/
  };
  Position? positione;
  var latitude;
  var longatute;

  // Set<Marker> _markers = {};

  _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    positione = await Geolocator.getCurrentPosition();

    setState(() {
      latitude = positione!.latitude;
      longatute = positione!.longitude;
      currentPostion = Marker(
        markerId: MarkerId("ID"),
        position: LatLng(positione!.latitude, positione!.longitude),
        onTap: () {
          setState(() {});
          print("${LatLng(positione!.latitude, positione!.longitude)}");
        },
      );
      _kGooglePlex = CameraPosition(
          target: LatLng(positione!.latitude, positione!.longitude), zoom: 20);
    });
  }

  // need a method to read list of data from firebase database
  // and add it to the list
  // void _onMapTap(LatLng latLng) {
  //   setState(() {
  //     print("Clicked..........$latLng");
  //     _markers.add(
  //       Marker(
  //         markerId: MarkerId('new_marker_${_markers.length}'),
  //         position: latLng,
  //         onTap: () {
  //           print("Marker Clicked");
  //         },
  //       ),
  //     );
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return _kGooglePlex == null
        ? Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          )
        : Scaffold(
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerFloat,
            body: GoogleMap(
              myLocationEnabled: true,
              mapType: MapType.normal,
              initialCameraPosition: _kGooglePlex!,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
              },
              markers: Set<Marker>.of(list),
              onTap: (latLng) {
                print("Clicked..........$latLng");
                setState(() {});
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (
                      context,
                    ) =>
                            ParkingRegistrationPage(
                                latLng.latitude, latLng!.longitude)));

                setState(() {
                  currentPostion = Marker(
                    markerId: MarkerId('new_marker_${list.length}'),
                    position: latLng,
                    onTap: () {
                      print("Marker Clicked");
                    },
                  );
                });
              },
            ),
            floatingActionButton: FloatingActionButton.extended(
              onPressed: _addParkCurrentLocation,
              label: const Text('Add Park\nCurrent Location'),
              icon: const Icon(Icons.add),
            ),
          );
  }

  Future<void> _addParkCurrentLocation() async {
    _determinePosition();
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(_kGooglePlex!));

    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (
          context,
        ) =>
                ParkingRegistrationPage(
                    positione!.latitude, positione!.longitude)));
  }
}
