// ignore_for_file: prefer_const_constructors_in_immutables, prefer_const_constructors

import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:parking_app/page/home.dart';
import 'package:parking_app/page/review/user_review.dart';

import '../../../../../utils/styles.dart';
import '../../customs/custom_label_for_text_field.dart';
import '../../customs/custom_text_field.dart';
import '../../utils/colors_code.dart';
import '../mobile_sign_in_page.dart';

class AddUserReview extends StatefulWidget {
  AddUserReview(this.id, {Key? key}) : super(key: key);
  var id;

  @override
  State<AddUserReview> createState() => _AddUserReviewState();
}

class _AddUserReviewState extends State<AddUserReview> {
  TextEditingController review = TextEditingController();

  String? name;
  String? email;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserInfo();
  }

  void getUserInfo() async {
    final currentUser = FirebaseAuth.instance;
    final ref = FirebaseDatabase.instance.ref();

    print("namedfkldj method calls");
    final snapshot = await ref.child('User').child(currentUser.currentUser!.uid);

    snapshot.onValue.listen((DatabaseEvent event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>;

      name = data['name'];
      email = data['email'];

      print("namedfkldj $name $email");
    });



  }
  double ratingBar = 0;

  void AddParkingReviewData(
    String parkingReview,) async {
    setState(() {
      //loding = true;
    });

    User? currentUser = FirebaseAuth.instance.currentUser;

    final databaseRef = FirebaseDatabase.instance.ref("UserReview");
    var id = DateTime.now().microsecondsSinceEpoch.toString();

    databaseRef.child(widget.id).child(id).set({
      "parkingReview": parkingReview,
      "uid": currentUser!.uid,
      "ratingBar": ratingBar,

      "name": name,
      "email": email,
    }).then((value) {
      Fluttertoast.showToast(
          msg: "Sucessfully",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.black,
          textColor: Colors.red,
          fontSize: 16.0);
      setState(() {
        // loding = false;
      });
      Fluttertoast.showToast(msg: "Register Sucessfully !");

      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) => Home()), (route) => false);
    }).onError((error, stackTrace) {
      Fluttertoast.showToast(msg: error.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsCode.page_background_color,

      appBar: AppBar(
        backgroundColor: ColorsCode.primary_color,
        actions: [
          IconButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => MobileSignInView()),
                    (route) => false);
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          //height: Get.height,
          padding: EdgeInsets.only(left: 0, top: 120, right: 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Center(
                child: CustomLabelField(
                  text: "User Review ",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Roboto'),
                ),
              ),
              Style.distan_size20,
              CustomLabelField(
                text: "Write Review About User",
                style: Style.robotoRegular,
              ),
              CustomTextField(
                baseColor: ColorsCode.text_field_base_colors,
                borderColor: ColorsCode.text_border_color,
                errorColor: ColorsCode.text_field_error_colors,
                controller: review,
                hint: "",
                inputType: TextInputType.text,
                icon: null,
                eyesIcon: false,
                onChangedFunction: null,
                // validator: Validator.validateEmail,
              ),
              Center(
                child: RatingBar.builder(
                  initialRating: 3,
                  minRating: 1,
                  direction: Axis.horizontal,
                  allowHalfRating: true,
                  itemCount: 5,
                  itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                  itemBuilder: (context, _) => Icon(
                    Icons.star,
                    color: Colors.amber,
                  ),
                  onRatingUpdate: (rating) {
                    setState(() {
                      ratingBar = rating ;
                    });
                    print(ratingBar);
                  },
                ),
              ),
              Style.distan_size20,

              Container(
                width: double.infinity,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GestureDetector(
                      onTap: () {
                        var reviewText = review.text.trim().toString();
                        if (reviewText.isEmpty) {
                          setState(() {
                            Fluttertoast.showToast(
                              msg: "Name con not be empty !",
                            );
                          });
                        } else {
                          AddParkingReviewData(
                            reviewText,
                          );
                        }
                        // Get.offAndToNamed(RouteManeger.gymadmission);
                      },
                      child: Container(
                        height: 35,
                        width: 100,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.0),
                          color: Color(0xff128041),
                        ),
                        child: Center(
                          child: Text(
                            "Confirm",
                            style: TextStyle(
                                color: Color(0xFFFFFFFF),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Roboto'),
                          ),
                        ),
                      ),
                    ),
                    Style.distan_size5,
                  ],
                ),
              ),
            ],
          ),
        ),
      ), // Column
    );
  }
}
