// ignore_for_file: prefer_const_constructors_in_immutables, prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../../../utils/styles.dart';
import '../../customs/custom_label_for_text_field.dart';
import '../../customs/custom_text_field.dart';
import '../../utils/colors_code.dart';
import '../mobile_sign_in_page.dart';
import 'add_user_review.dart';

class UserReview extends StatefulWidget {
  UserReview(this.id, {Key? key}) : super(key: key);
  var id;

  @override
  State<UserReview> createState() => _UserReviewState();
}

class _UserReviewState extends State<UserReview> {

  List<dynamic> list = [];
  final currentUser = FirebaseAuth.instance;

  final databaseRef = FirebaseDatabase.instance.ref("UserReview");




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsCode.page_background_color,
      floatingActionButton: FloatingActionButton(
        backgroundColor: ColorsCode.primary_color,
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => AddUserReview(widget.id)));
        },
        child: Icon(Icons.add),
      ),
      appBar: AppBar(
        backgroundColor: ColorsCode.primary_color,
        actions: [
          IconButton(
              onPressed: () {
                FirebaseAuth.instance.signOut();
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => MobileSignInView()),
                        (route) => false);
              },
              icon: Icon(Icons.logout))
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.only(left: 0, top: 10, right: 0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              StreamBuilder(
                  stream: databaseRef.child(widget.id).onValue,
                  builder: (context, AsyncSnapshot<DatabaseEvent> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(child:
                      Text("No Reviews",style: TextStyle(color: ColorsCode.primary_color,fontSize: 20),));
                    }else{


                      Map<dynamic, dynamic> map =
                      snapshot.data!.snapshot.value as dynamic;
                      List<dynamic> list = [];
                      list.clear();
                      list = map.values.toList();

                      return ListView.builder(
                          shrinkWrap: true,
                          itemCount: snapshot.data!.snapshot.children.length,
                          itemBuilder: (context, index) {
                            var ratd=double.parse(list[index]["ratingBar"].toString());

                            return Container(
                              padding: EdgeInsets.all(12),
                              margin: EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(12)),
                                border: Border.all(color: Colors.yellow,width: 2)
                              ),

                              child: Column(children: [
                                Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width: 110,
                                        child: Text("Name ", style: Style.textNormal),
                                      ),
                                      SizedBox(
                                        child: Text(": ${list[index]["name"].toString()}",
                                            style: Style.textNormal),
                                      )
                                    ]),
                                Style.distan_size5, Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width: 110,
                                        child: Text("Email ", style: Style.textNormal),
                                      ),
                                      SizedBox(
                                        child: Text(": ${list[index]["email"].toString()}",
                                            style: Style.textNormal),
                                      )
                                    ]),
                                Style.distan_size5, Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        width: 110,
                                        child: Text("Review ", style: Style.textNormal),
                                      ),
                                      SizedBox(
                                        child: Text(": ${list[index]["parkingReview"].toString()}",
                                            style: Style.textNormal),
                                      )
                                    ]),
                                Style.distan_size5,
                                Row(
                                  children: [
                                    // SizedBox(
                                    //   width: 10,
                                    // ),
                                    RatingBarIndicator(
                                      rating: ratd,
                                      itemBuilder: (context, index) => Icon(
                                        Icons.star,
                                        color: Colors.amber,
                                      ),
                                      itemCount: 5,
                                      itemSize: 15.0,
                                      direction: Axis.horizontal,
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    SizedBox(
                                      child: Text(ratd.toString(),
                                          style: Style.textNormal),
                                    )
                                  ],
                                ),
                                  Style.distan_size5,
                                ],),
                            );

                            // return ListTile(
                            //   title: Text(list[index]["parkingReview"]),
                            //   subtitle: Text(list[index]["parkingReview"]),
                            // );

                          });



                    }
                  })
            ],
          ),
        ),
      ), // Column
    );
  }
}
